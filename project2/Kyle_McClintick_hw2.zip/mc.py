#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import numpy as np
import random
from collections import defaultdict
#-------------------------------------------------------------------------
'''
    Monte-Carlo
    In this problem, you will implememnt an AI player for Blackjack.
    The main goal of this problem is to get familar with Monte-Carlo algorithm.
    You could test the correctness of your code 
    by typing 'nosetests -v mc_test.py' in the terminal.
    
    You don't have to follow the comments to write your code. They are provided
    as hints in case you need. 
'''
#-------------------------------------------------------------------------

def initial_policy(observation):
    """A policy that sticks if the player score is >= 20 and his otherwise
    
    Parameters:
    -----------
    observation:
    Returns:
    --------
    action: 0 or 1
        0: STICK
        1: HIT
    """
    ############################
    # obs is (21, 10, True) current sum, dealers face up card, boolean for playable ace in hand
    # get parameters from observation
    current_sum = observation[0]

    # action
    if current_sum < 20:
        action = 1
    else:
        action = 0
    ############################
    return action 

def mc_prediction(policy, env, n_episodes, gamma = 1.0):
    """Given policy using sampling to calculate the value function 
        by using Monte Carlo first visit algorithm.
    
    Parameters:
    -----------
    policy: function
        A function that maps an obversation to action probabilities
    env: function
        OpenAI gym environment
    n_episodes: int
        Number of episodes to sample
    gamma: float
        Gamma discount factor
    Returns:
    --------
    V: defaultdict(float)
        A dictionary that maps from state to value
    """
    # initialize empty dictionaries
    returns_sum = defaultdict(float)
    returns_count = defaultdict(float)
    # a nested dictionary that maps state -> value
    V = defaultdict(float)
    
    ############################

    # loop each episode
    for episode in range(n_episodes):
        # initialize the episode
        ob = env.reset()
        done = False
        # generate empty episode
        current_episode = []
        # loop until episode generation is done
        states = []
        while not done:
            states.append(ob)
            # select an action
            a = policy(ob)
            # return a reward and new state
            new_ob, r, done, info = env.step(a)
            # append state, action, reward to episode
            current_episode.append((ob,a,r))
            # update state to new state
            ob = new_ob

        # loop each state
        G=0
        for t in range(len(current_episode)-1, -1, -1):
            # sum up all rewards with discount_factor since the first visit
            G = G*gamma + current_episode[t][2]
            
            # calculate average return for this state over all sampled episodes
            current_state = current_episode[t][0]
            # if the state has not occurred before this time, add its returns
            if current_state not in states[:t]:
                returns_count[current_state] += 1
                returns_sum[current_state] += G
                V[current_state] = returns_sum[current_state] / returns_count[current_state]

    ############################
    
    return V

def epsilon_greedy(Q, state, nA, epsilon = 0.1):
    """Selects epsilon-greedy action for supplied state.
    
    Parameters:
    -----------
    Q: dict()
        A dictionary  that maps from state -> action-values,
        where A[s][a] is the estimated action value corresponding to state s and action a. 
    state: int
        current state
    nA: int
        Number of actions in the environment
    epsilon: float
        The probability to select a random action, range between 0 and 1
    
    Returns:
    --------
    action: int
        action based current state
    Hints:
    ------
    With probability (1 − epsilon) choose the greedy action.
    With probability epsilon choose an action at random.
    """
    ############################
    if np.random.rand(1) < (1 - epsilon):
        action = np.argmax(Q[state][:])
    else:
        action = np.random.randint(0, nA)
    ############################
    return action

def mc_control_epsilon_greedy(env, n_episodes, gamma = 1.0, epsilon = 0.1):
    """Monte Carlo control with exploring starts. 
        Find an optimal epsilon-greedy policy.
    
    Parameters:
    -----------
    env: function
        OpenAI gym environment
    n_episodes: int
        Number of episodes to sample
    gamma: float
        Gamma discount factor
    epsilon: float
        The probability to select a random action, range between 0 and 1
    Returns:
    --------
    Q: dict()
        A dictionary  that maps from state -> action-values,
        where A[s][a] is the estimated action value corresponding to state s and action a.
    Hint:
    -----
    You could consider decaying epsilon, i.e. epsilon = 1-0.1/n_episode during each episode
    and episode must > 0.    
    """
    
    returns_sum = defaultdict(float)
    returns_count = defaultdict(float)
    # a nested dictionary that maps state -> (action -> action-value)
    # e.g. Q[state] = np.darrary(nA)
    Q = defaultdict(lambda: np.zeros(env.action_space.n))
    
    ############################

    for i in range(n_episodes):
        # define decaying epsilon
        if i > 0:
            epsilon = epsilon - 0.1/n_episodes
        # initialize the episode
        ob = env.reset()
        done = False
        # generate empty episode
        current_episode = []
        # loop until one episode generation is done
        states_actions = []
        while not done:
            # get an action from epsilon greedy policy
            nA = len(Q[ob])
            a = epsilon_greedy(Q, ob, nA, epsilon)
            states_actions.append((ob, a))
            # return a reward and new state
            new_ob, r, done, info = env.step(a)
            # append state, action, reward to episode
            current_episode.append((ob, a, r))
            # update state to new state
            ob = new_ob

        # loop each state,action pair
        G = 0
        for t in range(len(current_episode) - 1, -1, -1):
            G = gamma*G + current_episode[t][2]

            current_state = current_episode[t][0]
            current_action = current_episode[t][1]
            # if the state action pair has not occured up until this time in the episode,
            if (current_state, current_action) not in states_actions[:t]:
                # append G to returns
                returns_sum[current_state] += G
                # update count
                returns_count[current_state] += 1
                # Q is the average of returns
                Q[current_state][current_action] = returns_sum[current_state] / returns_count[current_state]



        
    return Q